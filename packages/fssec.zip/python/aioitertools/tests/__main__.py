# Copyright 2019 John Reese
# Licensed under the MIT license

import unittest

if __name__ == "__main__":  # pragma: no cover
    unittest.main(module="aioitertools.tests", verbosity=2)
